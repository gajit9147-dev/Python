n =  int(input("Enter the first number: "))

if n%2 ==0:
    print(n, "is an even number")
else:
    print(n, "is an odd number")